# Ellis–Newton External Einstein Toolkit Reproduction — GitHub Actions v2

This repository is a **ready-to-run external reproduction harness** for the
periodic nonsilent Einstein–dust Cauchy family used in the Newton precision
cosmology manuscript.

## What counts as the external test

The GitHub Actions workflow builds and runs a real Einstein Toolkit
CarpetX/SpacetimeX executable in the upstream `einsteintoolkit/carpetx:cpu-real64`
container. It does **not** call the in-house Python ADM/BSSN solvers.

The pinned SpacetimeX source is:

`e89fe1d3ee47adaf881f051c502fac61e4a4c0f9`

The custom `EllisDustX` thorn supplies exactly the same Cauchy family and
translates the paper convention

`K_paper = +1/2 d_t h`

to Einstein Toolkit's standard ADM convention

`K_ET = -K_paper`.

It also converts the paper density variable `kappa*rho` to the ET source
`rho_ET=(kappa*rho)/(8*pi)`.

## Phase A

One executable is built, then the same problem is evolved at N=16,24,32 with

- periodic T^3 domain [0,2pi]^3,
- RK4,
- fixed physical time step 0.00025,
- BSSN limit of SpacetimeX Z4c,
- alpha=1 and beta=0 frozen,
- no artificial dissipation,
- final time t=0.18.

CarpetX's own norm output records density and the independent Z4c Hamiltonian
and momentum constraints. Diagnostics are sampled at t=0.09 and t=0.18.

`phaseA_release_gate.py` refuses to pass unless all three resolutions are
present, density stays positive, both constraints remain below the declared
preflight threshold, the target times are actually present, and the fine
resolution improves on the coarse one.

Phase A is intentionally **not** the full C1-C4 external certification. Its
purpose is to answer the most important first question: does a genuinely
external Einstein Toolkit evolution preserve the same positive-density,
constraint-clean finite-time solution?

## How to launch

1. Put this repository in GitHub.
2. Open **Actions**.
3. Select **Ellis External Einstein Toolkit Reproduction**.
4. Choose **Run workflow**.
5. Download the `ellis-einstein-toolkit-phase-a` artifact after it finishes.

Do not edit `external_phaseA_metrics.json` by hand. It must be generated from
CarpetX norm files in the external job.

## Scientific claim boundary

Before a real workflow has completed, status is:

`EXTERNAL_NR_REPLAY_NOT_YET_EXECUTED`

After a real artifact exists and its provenance is verified, Phase A may be
reported as an independent Einstein Toolkit finite-time evolution. Full
external C1-C4 / E-H / Newton–Ellis reconstruction remains a second gate.
