# Upload and auto-run

The normal ChatGPT GitHub connector is read-only for repository contents, so this package is designed to start automatically as soon as its files land on the `main` branch.

## Browser route

1. Extract this ZIP.
2. Open `https://github.com/tonynewton79-web/ellis-external-nr`.
3. Use **Add file -> Upload files**.
4. Upload the extracted repository contents, preserving the `.github/workflows`, `EllisDustX`, `par`, `scripts`, and `reference` directories.
5. Commit directly to `main`.

The `push` event then starts **Ellis External Einstein Toolkit Reproduction** automatically.

## Git command route

From the extracted package directory:

```bash
git init
git branch -M main
git remote add origin https://github.com/tonynewton79-web/ellis-external-nr.git
git add .
git commit -m "Add external Einstein Toolkit reproduction harness"
git push -u origin main
```

Use your normal GitHub authentication on your own machine. Do not send tokens or passwords to ChatGPT.

After the push, open the repository's **Actions** tab. The workflow should be running automatically.
