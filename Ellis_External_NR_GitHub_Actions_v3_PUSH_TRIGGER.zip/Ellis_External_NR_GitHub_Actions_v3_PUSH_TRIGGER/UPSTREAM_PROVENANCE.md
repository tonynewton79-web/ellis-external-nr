# Upstream provenance

The GitHub Actions harness pins the public Einstein Toolkit SpacetimeX repository
to commit:

`e89fe1d3ee47adaf881f051c502fac61e4a4c0f9`

This is the protected `main` branch head observed during preparation of the
package. At that revision, SpacetimeX's own CI declares the CPU real64 container

`einsteintoolkit/carpetx:cpu-real64`

and its official scripts download Cactus/CarpetX dependencies and build
`exe/cactus_sim` via SimFactory.

The harness copies `EllisDustX` into the checked-out SpacetimeX tree and adds
`SpacetimeX/EllisDustX` to the local thorn list before invoking the upstream
download/build scripts.

No external-result JSON is bundled as a claimed measurement. The workflow must
create the result from fresh CarpetX norm files.
