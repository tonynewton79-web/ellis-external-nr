#!/usr/bin/env python3
from pathlib import Path

template = Path("par/ellis_dust_z4c.template.par").read_text()
out = Path("generated_par")
out.mkdir(exist_ok=True)

for n in (16, 24, 32):
    text = (template
            .replace("@N@", str(n))
            .replace("@TEND@", "0.18")
            .replace("@OUTDIR@", f"external_results/N{n}"))
    path = out / f"ellis_dust_z4c_N{n}.par"
    path.write_text(text)
    print(path)
