#!/usr/bin/env python3
import json, math
from pathlib import Path

p = Path("external_phaseA_metrics.json")
if not p.exists():
    raise SystemExit("REFUSE: no external_phaseA_metrics.json")

d = json.loads(p.read_text())
if not d.get("external_execution_observed"):
    raise SystemExit("REFUSE: no parsed external execution")

res = d.get("resolutions", [])
if res != [16, 24, 32]:
    raise SystemExit(f"REFUSE: expected resolutions [16,24,32], got {res}")

for n in res:
    for t in ("0.09","0.18"):
        s = d["samples"][str(n)][t]
        if s["rho8pi_min"] <= 0:
            raise SystemExit(f"REFUSE: non-positive density at N={n}, t={t}")
        if s["hamiltonian_maxabs"] >= 1e-4:
            raise SystemExit(f"REFUSE: Hamiltonian too large at N={n}, t={t}: {s['hamiltonian_maxabs']}")
        if s["momentum_maxabs"] >= 1e-4:
            raise SystemExit(f"REFUSE: momentum too large at N={n}, t={t}: {s['momentum_maxabs']}")
        if abs(s["actual_time_min"] - float(t)) > 2e-8 or abs(s["actual_time_max"] - float(t)) > 2e-8:
            raise SystemExit(f"REFUSE: target time mismatch at N={n}, t={t}")

# Require improvement from coarse to fine at the later diagnostic time.
s16 = d["samples"]["16"]["0.18"]
s32 = d["samples"]["32"]["0.18"]
if not (s32["hamiltonian_maxabs"] < s16["hamiltonian_maxabs"]):
    raise SystemExit("REFUSE: Hamiltonian does not improve N16 -> N32")
if not (s32["momentum_maxabs"] < s16["momentum_maxabs"]):
    raise SystemExit("REFUSE: momentum does not improve N16 -> N32")

print("PASS_PHASE_A_EXTERNAL_ET_EVOLUTION")
print("This is NOT yet the full C1-C4 external reproduction gate.")
