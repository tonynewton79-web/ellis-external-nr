#!/usr/bin/env python3
from pathlib import Path
import sys

p = Path(sys.argv[1])
text = p.read_text()
needle = "SpacetimeX/Z4c\n"
if "SpacetimeX/EllisDustX" not in text:
    if needle not in text:
        raise SystemExit("Could not find SpacetimeX/Z4c in thorn list")
    text = text.replace(needle, needle + "SpacetimeX/EllisDustX\n")
    p.write_text(text)
print("EllisDustX present in thorn list:", "SpacetimeX/EllisDustX" in p.read_text())
