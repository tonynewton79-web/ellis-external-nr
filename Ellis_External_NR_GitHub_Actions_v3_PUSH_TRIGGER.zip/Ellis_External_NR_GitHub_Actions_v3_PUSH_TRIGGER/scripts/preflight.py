#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
errors = []

required = [
    ".github/workflows/ellis-external-et.yml",
    "EllisDustX/interface.ccl",
    "EllisDustX/schedule.ccl",
    "EllisDustX/param.ccl",
    "EllisDustX/configuration.ccl",
    "EllisDustX/src/make.code.defn",
    "EllisDustX/src/ellis_dustx.cxx",
    "par/ellis_dust_z4c.template.par",
    "scripts/patch_thornlist.py",
    "scripts/make_parfiles.py",
    "scripts/collect_norms.py",
    "scripts/phaseA_release_gate.py",
]
for p in required:
    if not (root/p).exists():
        errors.append("missing " + p)

src = (root/"EllisDustX/src/ellis_dustx.cxx").read_text()
sched = (root/"EllisDustX/schedule.ccl").read_text()
for fn in re.findall(r'SCHEDULE\s+(EllisDustX_\w+)', sched):
    if f'void {fn}(CCTK_ARGUMENTS)' not in src:
        errors.append("scheduled function absent in source: " + fn)

for fn in re.findall(r'extern "C" void (EllisDustX_\w+)\(CCTK_ARGUMENTS\)', src):
    if fn != "EllisDustX_Boundaries" and fn not in sched:
        errors.append("source function not scheduled: " + fn)

par = (root/"par/ellis_dust_z4c.template.par").read_text()
for token in ("@N@", "@TEND@", "@OUTDIR@"):
    if token not in par:
        errors.append("missing template token " + token)

if "K^ET_ij = - K^paper_ij" not in src:
    errors.append("missing explicit extrinsic-curvature sign translation")
if "rho_(p.I) / (8 * pi)" not in src:
    errors.append("missing 8pi matter normalization")
if "rr(p.I) = alpha * Ktrace * rho_(p.I)" not in src:
    errors.append("missing dust continuity evolution")
if "rR(p.I) = -alpha * Ktrace * R_(p.I) / 3" not in src:
    errors.append("missing Ellis-scale evolution")

wf = (root/".github/workflows/ellis-external-et.yml").read_text()
for s in ("einsteintoolkit/carpetx:cpu-real64",
          "e89fe1d3ee47adaf881f051c502fac61e4a4c0f9",
          "actions/upload-artifact@v4"):
    if s not in wf:
        errors.append("workflow missing " + s)

if errors:
    print("PRE-FLIGHT FAIL")
    for e in errors:
        print("-", e)
    raise SystemExit(1)
print("PRE-FLIGHT PASS")
print("This only validates the adapter/repository structure; it is not an external NR execution.")
