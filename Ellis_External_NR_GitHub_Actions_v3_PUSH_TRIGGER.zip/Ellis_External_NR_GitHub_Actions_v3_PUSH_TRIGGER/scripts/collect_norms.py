#!/usr/bin/env python3
from pathlib import Path
import json, math, re, sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "workspace/Cactus/external_results")
TARGETS = (0.09, 0.18)

def parse_norm(path):
    lines = [ln.strip() for ln in path.read_text(errors="replace").splitlines() if ln.strip()]
    header = next((ln for ln in lines if ln.startswith("#") and "1:iteration" in ln), None)
    if header is None:
        return None
    cols = header.lstrip("# ").split("\t")
    names = []
    for c in cols:
        if ":" in c:
            names.append(c.split(":",1)[1])
        else:
            names.append(c)
    rows = []
    for ln in lines:
        if ln.startswith("#"):
            continue
        parts = ln.split()
        if len(parts) != len(names):
            continue
        try:
            vals = [float(x) for x in parts]
        except ValueError:
            continue
        rows.append(dict(zip(names, vals)))
    return {"path": str(path), "header": names, "rows": rows}

def identify(parsed):
    h = " ".join(parsed["header"]).lower()
    if "ellisdustx::rho8pi." in h:
        return "rho8pi"
    if "ellisdustx::r_ellis." in h:
        return "R_Ellis"
    if "z4c::hc." in h:
        return "HC"
    for c in ("mtcx","mtcy","mtcz"):
        if f"z4c::{c}." in h:
            return c
    return None

def nearest(rows, target):
    if not rows:
        raise RuntimeError("no rows")
    return min(rows, key=lambda r: abs(r.get("time", 1e300)-target))

def get_suffix(row, suffix):
    for k,v in row.items():
        if k.lower().endswith("." + suffix.lower()):
            return v
    raise KeyError(suffix)

allruns = {}
for d in sorted(ROOT.glob("N*")):
    if not d.is_dir():
        continue
    m = re.match(r"N(\d+)", d.name)
    if not m:
        continue
    n = int(m.group(1))
    vars = {}
    for p in d.rglob("*.tsv"):
        q = parse_norm(p)
        if q:
            ident = identify(q)
            if ident:
                vars[ident] = q
    required = {"rho8pi","R_Ellis","HC","mtcx","mtcy","mtcz"}
    missing = required - vars.keys()
    if missing:
        print(f"WARNING N={n}: missing norm files {sorted(missing)}", file=sys.stderr)
        continue

    samples = {}
    for target in TARGETS:
        rho = nearest(vars["rho8pi"]["rows"], target)
        R = nearest(vars["R_Ellis"]["rows"], target)
        hc = nearest(vars["HC"]["rows"], target)
        ms = [nearest(vars[c]["rows"], target) for c in ("mtcx","mtcy","mtcz")]
        actual_times = [rho["time"], R["time"], hc["time"]] + [r["time"] for r in ms]
        samples[str(target)] = {
            "actual_time_min": min(actual_times),
            "actual_time_max": max(actual_times),
            "rho8pi_min": get_suffix(rho, "min"),
            "rho8pi_max": get_suffix(rho, "max"),
            "R_min": get_suffix(R, "min"),
            "R_max": get_suffix(R, "max"),
            "hamiltonian_maxabs": get_suffix(hc, "maxabs"),
            "momentum_component_maxabs": [get_suffix(r, "maxabs") for r in ms],
            "momentum_maxabs": max(get_suffix(r, "maxabs") for r in ms),
        }
    allruns[str(n)] = samples

result = {
    "framework": "Einstein Toolkit / CarpetX / SpacetimeX Z4c with set_Theta_zero=yes",
    "phase": "A_external_evolution_constraints_and_density",
    "resolutions": sorted(int(x) for x in allruns),
    "samples": allruns,
    "external_execution_observed": bool(allruns),
}
Path("external_phaseA_metrics.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
