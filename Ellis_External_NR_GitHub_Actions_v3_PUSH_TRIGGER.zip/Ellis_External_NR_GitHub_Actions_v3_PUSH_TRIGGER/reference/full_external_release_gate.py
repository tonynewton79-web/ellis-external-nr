#!/usr/bin/env python3
"""Conservative external-replay release gate.

This script does not manufacture a PASS. It requires a JSON populated by a real
third-party executable run at two resolutions and t=0.09,0.18.
"""
import argparse,json,math,sys

REQ=['hamiltonian_inf','momentum_inf','rho8pi_min','H_inf','DR_inf','E_bianchi_rel','H_bianchi_rel','newton_ellis_rel','C1_rel','C2_rel','C3_rel','C4_rel']
THR={'E_bianchi_rel':5e-3,'H_bianchi_rel':5e-3,'newton_ellis_rel':5e-3,'C1_rel':5e-3,'C2_rel':5e-3,'C3_rel':1e-2,'C4_rel':5e-2}

def fail(msg, ledger): ledger.append(('FAIL',msg))
def pas(msg, ledger): ledger.append(('PASS',msg))

def main(path):
    d=json.load(open(path)); ledger=[]
    runs=d.get('runs',[])
    if not d.get('K_sign_translation_applied'): fail('K sign translation not declared',ledger)
    else: pas('K_ET=-K_paper translation declared',ledger)
    if not d.get('density_8pi_translation_applied'): fail('8pi density translation not declared',ledger)
    else: pas('rho_ET=rho8pi/(8pi) translation declared',ledger)
    if len(runs)<4: fail('need >=4 runs: two resolutions x two proper times',ledger)
    for i,r in enumerate(runs):
        missing=[k for k in REQ if r.get(k) is None or not math.isfinite(float(r[k]))]
        if missing: fail(f'run {i} missing finite metrics: {missing}',ledger); continue
        if r['rho8pi_min']<=0: fail(f'run {i} density not positive',ledger)
        else: pas(f'run {i} rho8pi_min>0',ledger)
        if r['H_inf']<=1e-5: fail(f'run {i} magnetic Weyl inactive',ledger)
        else: pas(f'run {i} H active',ledger)
        if r['DR_inf']<=1e-5: fail(f'run {i} D R inactive',ledger)
        else: pas(f'run {i} D R active',ledger)
        for k,t in THR.items():
            if r[k] >= t: fail(f'run {i} {k}={r[k]:.3e} >= {t:.1e}',ledger)
            else: pas(f'run {i} {k}={r[k]:.3e}',ledger)
    # Pair coarse/fine by time and require constraint improvement.
    bytime={}
    for r in runs:
        if all(r.get(k) is not None for k in ['proper_time','resolution','hamiltonian_inf','momentum_inf']):
            bytime.setdefault(round(float(r['proper_time']),8),[]).append(r)
    for t,rr in bytime.items():
        if len(rr)<2: fail(f't={t}: fewer than two resolutions',ledger); continue
        rr=sorted(rr,key=lambda q:q['resolution']); c,f=rr[0],rr[-1]
        if f['hamiltonian_inf'] < c['hamiltonian_inf']: pas(f't={t}: Hamiltonian improves with resolution',ledger)
        else: fail(f't={t}: Hamiltonian does not improve',ledger)
        if f['momentum_inf'] < c['momentum_inf']: pas(f't={t}: momentum improves with resolution',ledger)
        else: fail(f't={t}: momentum does not improve',ledger)
        for k in ['rho8pi_min','H_inf','DR_inf']:
            scale=max(abs(f[k]),abs(c[k]),1e-30); rel=abs(f[k]-c[k])/scale
            if rel<0.05: pas(f't={t}: {k} cross-resolution agreement {rel:.2%}',ledger)
            else: fail(f't={t}: {k} cross-resolution disagreement {rel:.2%}',ledger)
    failures=[x for x in ledger if x[0]=='FAIL']
    print('\n'.join(f'[{s}] {m}' for s,m in ledger))
    print(f'\nSUMMARY: {len(ledger)-len(failures)} pass, {len(failures)} fail')
    print('STATUS:', 'EXTERNAL_NR_REPLAY_CERTIFIED' if not failures else 'EXTERNAL_NR_REPLAY_NOT_CERTIFIED')
    return 0 if not failures else 2

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('metrics_json'); a=ap.parse_args(); sys.exit(main(a.metrics_json))
