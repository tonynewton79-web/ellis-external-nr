# External Numerical-Relativity Replication Contract

This is the deliberately unclosed external-code gate for the v18 paper. No Einstein Toolkit, GRChombo, or other third-party numerical-relativity run is claimed here.

## Cauchy data

Use a periodic three-torus with coordinates `(x,y,z) in [0,2 pi)^3` and initial physical metric

\[
h_{ij}=\delta_{ij}.
\]

The paper's expansion-tensor convention is

\[
\partial_t h_{ij}=+2K_{ij},
\]

with

\[
K_{ij}=H_0\delta_{ij}+\partial_i\partial_j\phi+T_{ij},
\qquad
\phi=\varepsilon\cos x\cos y,
\]

\[
T_{ij}=A\cos z\,\mathrm{diag}(1,-1,0),
\qquad
(H_0,\varepsilon,A)=\left(1,\frac3{25},\frac2{25}\right).
\]

Set `R(0,x)=1`. Determine the dust density from the Hamiltonian constraint in the same normalization as the paper.

### Sign-convention translation

Many numerical-relativity infrastructures use

\[
K^{\rm ADM}_{ij}=-\frac12\mathcal L_n\gamma_{ij}.
\]

For those codes initialize

\[
K^{\rm ADM}_{ij}=-K_{ij}^{\rm paper}.
\]

Do not compare raw `K_ij` values until this convention has been translated.

## Required diagnostics

At matched fluid proper times `t=0.09` and `t=0.18`, report under at least two spatial resolutions:

- Hamiltonian and momentum constraint norms;
- `rho_min`;
- `||H_ab||_inf` and `||D R||_inf`;
- electric- and magnetic-Weyl propagation residuals;
- Newton-Ellis equation residual;
- metric-first `C1`, `C2`, `C3`, `C4` residuals using the expansion-normalized rest metric;
- lapse, shift and fluid four-velocity used to construct `u^a nabla_a`;
- resolution-convergence ratios.

The internal reference runs give positive density, nonzero magnetic Weyl curvature and nonzero `D R` at both comparison times. The external replay is not required to reproduce floating-point-identical residuals because discretization, gauge and formulation differ; it should reproduce the same continuum observables and show systematic convergence after all sign/gauge conventions are translated.

## Gauge rule

The commutator hierarchy is defined with the physical fluid proper-time derivative and the fluid-rest spatial geometry. Do not substitute a coordinate-time derivative or the intrinsic Laplacian of an arbitrary tilted coordinate slice without projecting back to the fluid rest space.

## External release status

`EXTERNAL_NR_REPLAY_NOT_YET_EXECUTED`
