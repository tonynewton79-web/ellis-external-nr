#include <loop.hxx>
#include <cctk.h>
#include <cctk_Arguments.h>
#include <cctk_Parameters.h>
#include <cmath>

namespace EllisDustX {
using namespace Loop;

extern "C" void EllisDustX_InitialGeometry(CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_EllisDustX_InitialGeometry;
  DECLARE_CCTK_PARAMETERS;

  GF3D<CCTK_REAL, 0, 0, 0> gxx_(cctkGH, gxx);
  GF3D<CCTK_REAL, 0, 0, 0> gxy_(cctkGH, gxy);
  GF3D<CCTK_REAL, 0, 0, 0> gxz_(cctkGH, gxz);
  GF3D<CCTK_REAL, 0, 0, 0> gyy_(cctkGH, gyy);
  GF3D<CCTK_REAL, 0, 0, 0> gyz_(cctkGH, gyz);
  GF3D<CCTK_REAL, 0, 0, 0> gzz_(cctkGH, gzz);

  GF3D<CCTK_REAL, 0, 0, 0> kxx_(cctkGH, kxx);
  GF3D<CCTK_REAL, 0, 0, 0> kxy_(cctkGH, kxy);
  GF3D<CCTK_REAL, 0, 0, 0> kxz_(cctkGH, kxz);
  GF3D<CCTK_REAL, 0, 0, 0> kyy_(cctkGH, kyy);
  GF3D<CCTK_REAL, 0, 0, 0> kyz_(cctkGH, kyz);
  GF3D<CCTK_REAL, 0, 0, 0> kzz_(cctkGH, kzz);

  GF3D<CCTK_REAL, 0, 0, 0> rho_(cctkGH, rho8pi);
  GF3D<CCTK_REAL, 0, 0, 0> R_(cctkGH, R_Ellis);

  loop_all<0, 0, 0>(cctkGH, [&](const PointDesc &p) {
    const CCTK_REAL c = std::cos(p.x) * std::cos(p.y);
    const CCTK_REAL s = std::sin(p.x) * std::sin(p.y);
    const CCTK_REAL q = std::cos(p.z);

    // Paper convention:
    //   K^paper_ij = + 1/2 d_t h_ij .
    // Einstein Toolkit ADMBase uses the standard opposite sign:
    //   K^ET_ij = - K^paper_ij .
    const CCTK_REAL Kpxx = H0 - epsilon * c + A * q;
    const CCTK_REAL Kpyy = H0 - epsilon * c - A * q;
    const CCTK_REAL Kpzz = H0;
    const CCTK_REAL Kpxy = epsilon * s;
    const CCTK_REAL theta = 3 * H0 - 2 * epsilon * c;

    const CCTK_REAL ksq =
        Kpxx * Kpxx + Kpyy * Kpyy + Kpzz * Kpzz +
        2 * Kpxy * Kpxy;

    gxx_(p.I) = 1;
    gxy_(p.I) = 0;
    gxz_(p.I) = 0;
    gyy_(p.I) = 1;
    gyz_(p.I) = 0;
    gzz_(p.I) = 1;

    kxx_(p.I) = -Kpxx;
    kxy_(p.I) = -Kpxy;
    kxz_(p.I) = 0;
    kyy_(p.I) = -Kpyy;
    kyz_(p.I) = 0;
    kzz_(p.I) = -Kpzz;

    // rho8pi stores the paper variable kappa*rho = 8*pi*rho_ET.
    // For flat initial h_ij and Lambda=0:
    //   8*pi*rho_ET = 1/2 (Theta^2 - K^paper_ij Kpaper^ij).
    rho_(p.I) = CCTK_REAL(0.5) * (theta * theta - ksq);
    R_(p.I) = 1;
  });
}

extern "C" void EllisDustX_InitialGauge(CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_EllisDustX_InitialGauge;

  GF3D<CCTK_REAL, 0, 0, 0> a(cctkGH, alp);
  GF3D<CCTK_REAL, 0, 0, 0> da(cctkGH, dtalp);
  GF3D<CCTK_REAL, 0, 0, 0> bx(cctkGH, betax);
  GF3D<CCTK_REAL, 0, 0, 0> by(cctkGH, betay);
  GF3D<CCTK_REAL, 0, 0, 0> bz(cctkGH, betaz);
  GF3D<CCTK_REAL, 0, 0, 0> dbx(cctkGH, dtbetax);
  GF3D<CCTK_REAL, 0, 0, 0> dby(cctkGH, dtbetay);
  GF3D<CCTK_REAL, 0, 0, 0> dbz(cctkGH, dtbetaz);

  loop_all<0, 0, 0>(cctkGH, [&](const PointDesc &p) {
    a(p.I) = 1;
    da(p.I) = 0;
    bx(p.I) = 0;
    by(p.I) = 0;
    bz(p.I) = 0;
    dbx(p.I) = 0;
    dby(p.I) = 0;
    dbz(p.I) = 0;
  });
}

extern "C" void EllisDustX_AddTmunu(CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_EllisDustX_AddTmunu;

  GF3D<CCTK_REAL, 0, 0, 0> rho_(cctkGH, rho8pi);
  GF3D<CCTK_REAL, 0, 0, 0> tt(cctkGH, eTtt);
  GF3D<CCTK_REAL, 0, 0, 0> tx(cctkGH, eTtx);
  GF3D<CCTK_REAL, 0, 0, 0> ty(cctkGH, eTty);
  GF3D<CCTK_REAL, 0, 0, 0> tz(cctkGH, eTtz);
  GF3D<CCTK_REAL, 0, 0, 0> xx(cctkGH, eTxx);
  GF3D<CCTK_REAL, 0, 0, 0> xy(cctkGH, eTxy);
  GF3D<CCTK_REAL, 0, 0, 0> xz(cctkGH, eTxz);
  GF3D<CCTK_REAL, 0, 0, 0> yy(cctkGH, eTyy);
  GF3D<CCTK_REAL, 0, 0, 0> yz(cctkGH, eTyz);
  GF3D<CCTK_REAL, 0, 0, 0> zz(cctkGH, eTzz);

  const CCTK_REAL pi = std::acos(CCTK_REAL(-1));

  loop_all<0, 0, 0>(cctkGH, [&](const PointDesc &p) {
    tt(p.I) += rho_(p.I) / (8 * pi);
    // Comoving pressureless dust in alpha=1, beta=0 gauge.
    tx(p.I) += 0;
    ty(p.I) += 0;
    tz(p.I) += 0;
    xx(p.I) += 0;
    xy(p.I) += 0;
    xz(p.I) += 0;
    yy(p.I) += 0;
    yz(p.I) += 0;
    zz(p.I) += 0;
  });
}

extern "C" void EllisDustX_SetTmunuRHS(CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_EllisDustX_SetTmunuRHS;

  GF3D<CCTK_REAL, 0, 0, 0> rho_(cctkGH, rho8pi);
  GF3D<CCTK_REAL, 0, 0, 0> tt(cctkGH, eTtt);
  GF3D<CCTK_REAL, 0, 0, 0> tx(cctkGH, eTtx);
  GF3D<CCTK_REAL, 0, 0, 0> ty(cctkGH, eTty);
  GF3D<CCTK_REAL, 0, 0, 0> tz(cctkGH, eTtz);
  GF3D<CCTK_REAL, 0, 0, 0> xx(cctkGH, eTxx);
  GF3D<CCTK_REAL, 0, 0, 0> xy(cctkGH, eTxy);
  GF3D<CCTK_REAL, 0, 0, 0> xz(cctkGH, eTxz);
  GF3D<CCTK_REAL, 0, 0, 0> yy(cctkGH, eTyy);
  GF3D<CCTK_REAL, 0, 0, 0> yz(cctkGH, eTyz);
  GF3D<CCTK_REAL, 0, 0, 0> zz(cctkGH, eTzz);

  const CCTK_REAL pi = std::acos(CCTK_REAL(-1));

  loop_int<0, 0, 0>(cctkGH, [&](const PointDesc &p) {
    tt(p.I) = rho_(p.I) / (8 * pi);
    tx(p.I) = 0;
    ty(p.I) = 0;
    tz(p.I) = 0;
    xx(p.I) = 0;
    xy(p.I) = 0;
    xz(p.I) = 0;
    yy(p.I) = 0;
    yz(p.I) = 0;
    zz(p.I) = 0;
  });
}

extern "C" void EllisDustX_RHS(CCTK_ARGUMENTS) {
  DECLARE_CCTK_ARGUMENTS_EllisDustX_RHS;

  GF3D<CCTK_REAL, 0, 0, 0> rho_(cctkGH, rho8pi);
  GF3D<CCTK_REAL, 0, 0, 0> R_(cctkGH, R_Ellis);
  GF3D<CCTK_REAL, 0, 0, 0> rr(cctkGH, rho8pi_rhs);
  GF3D<CCTK_REAL, 0, 0, 0> rR(cctkGH, R_Ellis_rhs);
  GF3D<CCTK_REAL, 0, 0, 0> kh(cctkGH, Kh);
  GF3D<CCTK_REAL, 0, 0, 0> thz(cctkGH, Theta);
  GF3D<CCTK_REAL, 0, 0, 0> ag(cctkGH, alphaG);

  loop_int<0, 0, 0>(cctkGH, [&](const PointDesc &p) {
    // Z4c reconstructs physical K = Kh + 2 Theta.
    // In the BSSN switch set_Theta_zero=yes, Theta is constrained to zero.
    const CCTK_REAL Ktrace = kh(p.I) + 2 * thz(p.I);
    const CCTK_REAL alpha = 1 + ag(p.I);

    // Standard-sign ADM Ktrace = - paper Theta, hence:
    // d_t rho = -Theta_paper rho = Ktrace rho
    // d_t R   = +(Theta_paper/3) R = -(Ktrace/3) R
    rr(p.I) = alpha * Ktrace * rho_(p.I);
    rR(p.I) = -alpha * Ktrace * R_(p.I) / 3;
  });
}

extern "C" void EllisDustX_Boundaries(CCTK_ARGUMENTS) {}

} // namespace EllisDustX
